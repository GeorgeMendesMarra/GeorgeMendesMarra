#!/bin/bash

# Nome do arquivo da biblioteca
JAR="commons-math3-3.6.1.jar"

# Compilar
echo "Compilando..."
javac -cp "$JAR" RaizesComplexas.java

# Verifica se a compilação deu certo
if [ $? -eq 0 ]; then
    echo "Executando..."
    java -cp ".:$JAR" RaizesComplexas
else
    echo "Erro na compilação."
fi
