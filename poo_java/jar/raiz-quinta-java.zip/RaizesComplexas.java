import org.apache.commons.math3.complex.Complex;

public class RaizesComplexas {
    public static void main(String[] args) {
        Complex numero = new Complex(-1, 0);
        Complex[] raizes = numero.nthRoot(5);

        System.out.println("Raízes quintas complexas de -1:");
        for (int i = 0; i < raizes.length; i++) {
            System.out.printf("Raiz %d: %s%n", i + 1, raizes[i]);
        }
    }
}
